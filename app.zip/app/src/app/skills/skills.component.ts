import { Component, OnInit } from '@angular/core';
import {GeneralInfoService} from '../general-info.service';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {

  mySkills:{};

  constructor(private generalInfo: GeneralInfoService ) { }

  ngOnInit(): void {

     this.generalInfo.getSkills().subscribe((res)=>{
        this.mySkills = res;
     });
  }

}
