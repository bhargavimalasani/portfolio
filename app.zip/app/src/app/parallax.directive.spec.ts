import { ParallaxDirective } from './parallax.directive';

describe('ParallaxDirective', () => {
  it('should create an instance', () => {
    const directive = new ParallaxDirective();
    expect(directive).toBeTruthy();
  });
});
