import { Directive } from '@angular/core';

@Directive({
  selector: '[appParallax]'
})
export class ParallaxDirective {

  constructor() { }

}
